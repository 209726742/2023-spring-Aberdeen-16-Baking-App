package com.example.sort1111.Domain

class CategoryDomain(var title: String)