package com.example.sort1111.Domain

class FastDeliveryDomain(var title: String, var pic: String, var star: Double, var time: Int)
